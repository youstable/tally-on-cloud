#!/bin/bash
# Automate installation of Tally ERP 9 or TallyPrime on a Linux-based cloud server

echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

echo "Installing dependencies (Wine, RDP, etc.)..."
sudo apt install -y wget unzip xrdp wine

echo "Downloading Tally installer (manual step needed if license required)..."
# wget <tally-download-link>

echo "Extracting and setting up Tally..."
# wine setup.exe /silent

echo "Tally setup completed. Configure RDP to access Tally remotely."
