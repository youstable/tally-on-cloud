#!/bin/bash
# Configure firewall rules for Tally on Cloud

sudo ufw allow 3389/tcp
sudo ufw allow 22/tcp
sudo ufw enable

echo "Firewall rules configured for RDP and SSH access."
