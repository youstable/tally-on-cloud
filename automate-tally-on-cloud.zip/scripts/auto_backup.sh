#!/bin/bash
# Automated backup for Tally data folder

BACKUP_SRC="/home/tally/Data"
BACKUP_DST="/home/tally/Backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DST
tar -czvf $BACKUP_DST/tally_backup_$TIMESTAMP.tar.gz $BACKUP_SRC

echo "Backup completed: $BACKUP_DST/tally_backup_$TIMESTAMP.tar.gz"
