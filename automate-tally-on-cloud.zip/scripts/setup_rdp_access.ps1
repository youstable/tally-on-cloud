# PowerShell script to enable multiple RDP connections on Windows Server

Write-Host "Enabling RDP access..."
Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name "fDenyTSConnections" -Value 0

Enable-NetFirewallRule -DisplayGroup "Remote Desktop"

Write-Host "RDP enabled successfully. Multiple users can now access the server."
