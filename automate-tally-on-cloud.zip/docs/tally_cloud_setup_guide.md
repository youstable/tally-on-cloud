# Tally on Cloud Setup Guide

This guide provides detailed instructions for setting up Tally ERP 9 or TallyPrime on a cloud server using the provided automation scripts.

## Steps:
1. Deploy a cloud server (Windows or Linux).
2. Run `install_tally_cloud.sh` to install Tally.
3. Use `setup_rdp_access.ps1` to configure RDP on Windows.
4. Enable automated backups using `auto_backup.sh`.
5. Apply firewall rules with `firewall_rules.sh`.

Access Tally remotely using your RDP client from any device.
