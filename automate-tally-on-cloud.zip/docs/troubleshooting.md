# Troubleshooting Tally on Cloud

## Common Issues

### 1. RDP not connecting
- Ensure port 3389 is open on firewall.
- Verify RDP service is running.

### 2. Tally not launching on Linux
- Verify Wine installation.
- Run `winecfg` and test basic apps.

### 3. Backup not working
- Check permissions of source data folder.
- Ensure enough disk space.
